8:07
群公告
2024前端
二面任务文档
首先，恭喜你通过一面，可喜可贺，可喜可贺。
接下来，你有一个国庆假期的时间准备你的二面小任务，我们会根据这个任务决定你是否成为我们的一员。
概览
入门文档

你可以参考以下的资源来完成你的小任务，也可以
去视频网站寻找视频教程，甚至，你可以向AI求
助，只要善于提问，他会告诉你一切需要的知识。
MDN (Mozilla Developer Network）是由
Mozilla组织创建和维护的一个开发者资源平台。
Mozilla是一个非营利性组织，他们开发了许多知
名的开源软件，如Firefox。
MDN的目标是为开发者提供高质量的文档和资
源，帮助他们学习使用Web技术。
你可以在这里学习前端三件套——HTML,CSS,
JavaScript。
网址：https://developer.mozilla.org/zh-CN/
，框架
你也可以选择使用前端框架完成小任务，这属于加分项，不过，建议对前端三件套有一定了解后再去了解框架。
Vue.js: https://cn.vuejs.org/
React: https://react.dev/
▼来自前端部的快速入门
当然，还有我们为你“精心”准备的文档？
（绝赞赶工中)
任务
我们的任务只是给你一个证明自己学习能力和代码能力的途径，如果你有自己的小想法，请尽情的发挥，不必完全贴合任务
要求，我们非常喜欢带有自己想法和特色
的小任务。
实现一个简易的问答平台。
DDL在国庆假期结束之前，具体时间请参见二面
群，过时未上传视为放弃二面。
完成后，请根据提交文档上传至GitHub仓库。
提交用 Github Repo:
https://github.com/hduhelp/frontend_2024_freshman_task.git。
将会在截止后择期进行线下考核二面任务，考核时间待定。
基本要求

以下对应要求应通过调用我们提供的简易API完成。
显示所有提问
对提问的新增，删除，修改。
显示对应提问的回答。
对答案的新增，删除，修改。（可选）
额外要求
自己设计一个好看的UI。
考虑多端适配，如手机，平板等。
完善的交互体验，如动画。
贴近真实软件，你可以尝试复刻一些知名问答
平台的UI，如 Zhihu，stackoverflow。
尝试实现更多功能，如点赞，评论等。
API 接口介绍
API 地址：https://hduhelp.woshiluo.com
/api/question GET 获取问题列表
/api/question POST 创建新的问题
/api/question/:id GET 获取编号为 id 的问题
/api/question/:id PUT 修改编号为 id 的问题
/api/question/:id/answer POST 创建新的答案
/api/question/:id/answer GET  获取编号为id的问题的答案列表
/api/question/:id/answer/:answerID GET 获取答案
/api/question/:id/answer/:answerID PUT 修改答案

类型
Question
JSON {
    "id":1,
    "title": "What is Go?"
    "detail": "I want to learn Go p
    "author":"Alice",
    "created _at":"2023-09-12T12:00"author_email": "alice@example."answers":[]
    Answer
}
Answer
JSON{
    "id":1,
    "content": "Go is an open-sourc"
    created _at":"2023-09-12T12:05"
    author_email": "bob@example.co"
    author _name":"Bob",
    "question_id":1,
    "is_best": true
}

在创建，修改问题时，answer 数组应为空。在获
取问题时，answers 数组返回 Answer[]
当前问题的所有答案。
可能涉及的知识点
使用HTML构建页面的基础布局
0了解常用的HTML标签
表示
HTML的列表（<ul><li>)
HTML的表格（<table>)
如何让HTML/CSS/JS相互配合
oHTML中书写CSS使用
引入CSS等资源使用
0书写月引入JS使用
使用CSS为页面赋予样式
<style>
<link>
<script>
。了解常见网页布局（了解 float, flex / grid
布局，综合运用不同布局来完成页面)
0使用CSS选择器 选中HTML元素添加样
式（id选择器/类选择器/ etc.)
自适应布局（查阅 媒体查询）
JS添加交互行为
0查阅 DOM操作入门
远程请求后端接口
如何运用JS请求 API接口获取JSON数据，
并展示到HTML中。
▼编写时可以注意的细节（非硬性要求)
代码编写
在自己的项目代码中添加必要的注释
使用良好的编程风格（注意缩进等）
尝试对相似的代码进行封装
o原则上尽量避免三种语言完成的任务相互耦
合，比如在HTML中内嵌大量行内样式
用户体验

为项目应用漂亮优雅的UX（印象分++)
对项目进行适配，如不同设备屏幕尺寸自适
应布局/暗黑模式/多语言切换（i18N)
。涉及与后端的交互，数据加载过程中需要给
用户足够的提示，如骨架屏或进度条加
载动画；加载数据失败时，可以通过
Toast
(轻提示)
等方式给予用户提示

涛
涛



评论全文
2人点赞

优质知识库推荐
WaytoAGl
AI知识库的免费源头
上更多的人因AI而强力
AI 鹊桥
跨越 AI 银河探索 AI之谜
专注于 AI实践的免费知识库
助力每个人因掌握AI而变得更强大
通往AGI之路-因AI而强大
通往 AGI之路-WaytoAGI：是由
一群热爱AI的专家和爱好者共同建设的
开源AI知识库，大家贡献并整合各….
玩转ChatGPT
查看更多>
Hi！我是Ryans.eth。致未来的探
索者们：我们坚信，拥抱人工智能(AI)
的力量，是每个人未来发展的必经...
Midjourney 中文笔记
欢迎来到《Midjourney 中文笔记》，
这是Snow.的个人的学习笔记，希望
对你有所帮助
收藏

一键收藏
飞书App内打开
关注文档更新

C分享