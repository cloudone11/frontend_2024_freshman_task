// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './components/Home';
import QuestionDetail from './components/QuestionDetail';
import AskQuestion from './components/AskQuestion';
import UserProfile from './components/UserProfile';
import QuestionEdit from './components/QuestionEdit';
import AnswerEdit from './components/AnswerEdit';
import Navbar from './components/Navbar';
import AddAnswer from './components/AddAnswer';
import UserProvider from './context/UserProvider';
const App = () => {
  return (
    <UserProvider>
      <Router>
      <Navbar />
      <div className="container">
        <div className="row">
          <div className="col-0 col-lg-2"></div>
          <div className="col-12 col-lg-8">
          <Routes>
            <Route path="/question/:id/addAnswer" element={<AddAnswer />} />
            <Route path="/" element={<Home />} />
            <Route path="/ask" element={<AskQuestion />} />
            <Route path="/question/:id" element={<QuestionDetail />} />
            <Route path="/user-profile" element={<UserProfile />} />
            <Route path="/edit/:id" element={<QuestionEdit />} />
            <Route path="/answer/:questionId/edit/:answerId" element={<AnswerEdit />} />
          </Routes>
          </div>
        </div>
      </div>
      
      </Router>
    </UserProvider>
    
  );
};

export default App;
