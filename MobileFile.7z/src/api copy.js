
let questions = [
    {
        id: 1,
        title: "What is Go?",
        detail: "I want to learn Go programming language.",
        author: "Alice",
        created_at: "2023-09-12T12:00",
        author_email: "alice@example.com",
        answers: [
            {
                id: 1,
                content: "Go is an open-source programming language.",
                created_at: "2023-09-12T12:05",
                author_email: "bob@example.com",
                author_name: "Bob",
                question_id: 1,
                is_best: true
            }
        ]
    }
];

let answers = [
    {
        id: 1,
        content: "Go is an open-source programming language.",
        created_at: "2023-09-12T12:05",
        author_email: "bob@example.com",
        author_name: "Bob",
        question_id: 1,
        is_best: true
    }
];

// 获取问题列表
export function getQuestions() {
    return new Promise((resolve) => {
        resolve(questions);
    });
}

// 创建新的问题
export function createQuestion(question) {
    return new Promise((resolve) => {
        question.id = questions.length + 1; // 简单自增ID
        questions.push(question);
        console.log(question);
        resolve('success');
    });
}

// 获取特定问题
export function getQuestionById(id) {
    return new Promise((resolve) => {
        // const question = questions.find(q => q.id === id);
        const question = questions.filter(q => q.id === id)[0];
        console.log(question);
        resolve(questions[0]);
    });
}

// 修改特定问题
export function updateQuestion(id, updatedQuestion) {
    return new Promise((resolve) => {
        let questionIndex = questions.findIndex(q => q.id === id);
        if (questionIndex !== -1) {
            questions[questionIndex] = { ...questions[questionIndex], ...updatedQuestion };
            console.log(questions[questionIndex]);
            resolve('success');
        } else {
            resolve('fail'); // 没有找到问题
        }
    });
}

// 创建新的答案
export function createAnswer(questionId, answer) {
    return new Promise((resolve) => {
        answer.id = answers.length + 1; // 简单自增ID
        answer.question_id = questionId;
        answers.push(answer);
        
        const question = questions.find(q => q.id === questionId);
        if (question) {
            question.answers.push(answer.id); // 将答案ID添加到问题中的答案列表
        }
        
        resolve(answer);
    });
}

// 获取特定问题的答案列表
export function getAnswersByQuestionId(questionId) {
    return new Promise((resolve) => {
        const questionAnswers = answers.filter(a => a.question_id === questionId);
        console.log(questionAnswers);
        resolve(answers);
    });
}

// 获取特定答案
export function getAnswerByIds(questionId, answerId) {
    return new Promise((resolve) => {
        // 假设这些ID是从某处获取的
    const questionId = 1;
    const answerId = 1;

    // 步骤 1: 筛选出匹配 questionId 的答案
    const filteredByQuestionId = answers.filter(a => a.question_id === questionId);

    // 步骤 2: 从结果中找到匹配 answerId 的答案
    const foundAnswer = filteredByQuestionId.find(a => a.id === answerId);

    console.log(foundAnswer);
    // 步骤 3: 返回答案
    resolve(foundAnswer);
        // const questionAnswers = answers.filter(a => a.question_id === questionId && a.id === answerId);
        // resolve(questionAnswers);
    });
    //     resolve(answers[0]);
    // });
}

// 修改答案
export function updateAnswer(answerId, updatedAnswer) {
    return new Promise((resolve) => {
        let answerIndex = answers.findIndex(a => a.id === answerId);
        if (answerIndex !== -1) {
            answers[answerIndex] = { ...answers[answerIndex], ...updatedAnswer };
            resolve('success');
        } else {
            resolve('fail'); // 没有找到答案
        }
    });
}
