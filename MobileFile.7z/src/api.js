import axios from 'axios';

// 设置API基础路径
const API_BASE_URL = 'https://hduhelp.woshiluo.com/api';

// 获取问题列表
export const getQuestions = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/question`);
    return response.data;
  } catch (error) {
    console.error('Error fetching questions:', error);
    throw error;
  }
};

// 创建新问题
export const createQuestion = async (questionData) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/question`, questionData);
    return response.data;
  } catch (error) {
    console.error('Error creating question:', error);
    throw error;
  }
};

// 获取指定ID的问题
export const getQuestionById = async (id) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/question/${id}`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching question with ID ${id}:`, error);
    throw error;
  }
};

// 修改指定ID的问题
export const updateQuestion = async (id, questionData) => {
  try {
    const response = await axios.put(`${API_BASE_URL}/question/${id}`, questionData);
    return response.data;
  } catch (error) {
    console.error(`Error updating question with ID ${id}:`, error);
    throw error;
  }
};

// 创建新答案
export const createAnswer = async (questionId, answerData) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/question/${questionId}/answer`, answerData);
    return response.data;
  } catch (error) {
    console.error(`Error creating answer for question ID ${questionId}:`, error);
    throw error;
  }
};

// 获取指定问题的所有答案
export const getAnswersByQuestionId = async (questionId) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/question/${questionId}/answer`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching answers for question ID ${questionId}:`, error);
    throw error;
  }
};

// 获取指定ID的答案
export const getAnswerByIds = async (questionId, answerId) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/question/${questionId}/answer/${answerId}`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching answer with ID ${answerId} for question ID ${questionId}:`, error);
    throw error;
  }
};

// 修改指定ID的答案
export const updateAnswer = async (questionId, answerId, answerData) => {
  try {
    const response = await axios.put(`${API_BASE_URL}/question/${questionId}/answer/${answerId}`, answerData);
    return response.data;
  } catch (error) {
    console.error(`Error updating answer with ID ${answerId} for question ID ${questionId}:`, error);
    throw error;
  }
};