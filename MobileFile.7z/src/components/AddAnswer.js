import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import UserContext from '../context/UserContext';
import { getQuestionById, createAnswer } from '../api';
const AddAnswer = () => {
  const navigate = useNavigate();

  const { user } = React.useContext(UserContext); // 获取用户信息

  const { id }= useParams();
  const [question, setQuestion] = useState({id: '', title: '', detail: '', author: '', author_email: '', created_at: '', answers: []});
  // const [answer, setAnswer] = useState({id: '', content: '', author_name: '', author_email: '', created_at: '', is_best: false, question_id: ''});
  const [content, setContent] = useState('');
  const [isBest, setIsBest] = useState(false);
  useEffect(() => {
    // 模拟从后端获取数据
    const fetchAnswerDetails = async () => {
      try {
        const questionData = await getQuestionById(id);
        setQuestion(questionData);
      } catch (error) {
        console.error('Error fetching answer details:', error);
      }
    };

    fetchAnswerDetails();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const addAnswer = {
      question_id: Number(id),
      content: content,
      author_name: user.name,
      author_email: user.email,
      created_at: new Date().toISOString(),
      is_best: isBest,
    };
    console.log('Updated answer:', addAnswer); // 打印更新信息用于调试
    try {
      const response = await createAnswer(Number(id),addAnswer);
      console.log('created answer:', addAnswer); // 打印更新信息用于调试
      console.log('created answer response:', response); // 打印更新响应信息用于调试
      navigate(`/question/${id}`); // 返回到问题详情页面
    } catch (error) {
      console.error('Error updating answer:', error);
    }
  };

  // if (!answer) return <div>Loading...</div>;

  return (
    <div className="container mt-4">
      <h1>编辑回答</h1>
      <h2>问题：{question.title}</h2>
      <span>作者：{question.author}  </span>
      <span>邮箱：{question.author_email}</span>
      <h2>详情：{question.detail}</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">回答内容</label>
          <textarea
            className="form-control"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            required
          />
        </div>
        <div className="mb-3 form-check">
          <input
            type="checkbox"
            className="form-check-input"
            checked={isBest}
            onChange={(e) => setIsBest(e.target.checked)}
          />
          <label className="form-check-label">是否置顶</label>
        </div>
        <button type="submit" className="btn btn-primary">提交</button>
      </form>
    </div>
  );
};

export default AddAnswer;
