import React, { useState, useEffect } from 'react';
// 使用useState和useEffect来管理表单数据和更新步骤：
// 1. useStete初始化数据。尽量模拟后端返回的数据，方便调试。
// 2. useEffect获取数据，并更新。尽量不使用块外变量，以便于组件重渲染。
import { useParams, useNavigate } from 'react-router-dom';
// useParams获取url中的参数返回一个对象，useNavigate用来跳转页面、先useNavigate再navigate。。。，useNavigate用来跳转页面。
import UserContext from '../context/UserContext';
// 引入UserContext，用于获取用户信息。const { user } = React.useContext(UserContext); // 获取用户信息
// 需要在app.js中引入UserContextProvider，将用户信息传递给子组件，再在子组件中使用React.useContext(UserContext)获取用户信息。
import { getQuestionById, updateAnswer } from '../api';
// 使用getAnswerByIds和getQuestionById来获取问题和回答数据，使用updateAnswer来更新回答数据。
const AnswerEdit = () => {
  const navigate = useNavigate();

  const { user } = React.useContext(UserContext); // 获取用户信息

  const { questionId, answerId } = useParams(); // 获取问题ID和回答ID
  // get question, answer, user info
  // question info:id, title, detail, author, author_email, created_at, answers
  // answer info:id, content, author_name, author_email, created_at, is_best,question_id
  // user info:name, email
  const [question, setQuestion] = useState({id: '', title: '', detail: '', author: '', author_email: '', created_at: '', answers: []});
  // const [answer, setAnswer] = useState({id: '', content: '', author_name: '', author_email: '', created_at: '', is_best: false, question_id: ''});
  const [content, setContent] = useState('');
  const [isBest, setIsBest] = useState(false);
  useEffect(() => {
    // 模拟从后端获取数据
    const fetchAnswerDetails = async () => {
      try {
        const questionData = await getQuestionById(questionId);
        const answerData = questionData.answers.find(answer => answer.id === Number(answerId));
        setQuestion(questionData);
        // console.log('Question data:', questionData); // 打印问题数据用于调试
        // console.log('Answer data:', answerData); // 打印回答数据用于调试
        setIsBest(answerData.is_best);
        setContent(answerData.content);
      } catch (error) {
        console.error('Error fetching answer details:', error);
      }
    };

    fetchAnswerDetails();
  }, [questionId, answerId]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const updatedAnswer = {
      
      question_id: Number(questionId),
      id: Number(answerId),
      content: content,
      author_name: user.name,
      author_email: user.email,
      created_at: new Date().toISOString(),
      is_best: isBest,
    };
    console.log('Updated answer:', updatedAnswer); // 打印更新信息用于调试
    try {
      const response = await updateAnswer(questionId,answerId,updatedAnswer);
      console.log('Updated answer:', updatedAnswer); // 打印更新信息用于调试
      console.log('Updated answer response:', response); // 打印更新响应信息用于调试
      navigate(`/question/${questionId}`); // 返回到问题详情页面
    } catch (error) {
      console.error('Error updating answer:', error);
    }
  };

  // if (!answer) return <div>Loading...</div>;

  return (
    <div className="container mt-4">
      <h1>编辑回答</h1>
      <h2>问题：{question.title}</h2>
      <span>作者：{question.author}  </span>
      <span>邮箱：{question.author_email}</span>
      <h2>详情：{question.detail}</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">回答内容</label>
          <textarea
            className="form-control"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            required
          />
        </div>
        <div className="mb-3 form-check">
          <input
            type="checkbox"
            className="form-check-input"
            checked={isBest}
            onChange={(e) => setIsBest(e.target.checked)}
          />
          <label className="form-check-label">是否置顶</label>
        </div>
        <button type="submit" className="btn btn-primary">提交</button>
      </form>
    </div>
  );
};

export default AnswerEdit;