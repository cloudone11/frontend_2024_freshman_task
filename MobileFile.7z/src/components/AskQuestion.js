// src/components/AskQuestion.js
import React, { useState } from 'react';
import { useNavigate } from "react-router-dom";
import UserContext from '../context/UserContext';
import {createQuestion} from '../api';
const AskQuestion = () => {
  const navigate = useNavigate();
  const { user } = React.useContext(UserContext);
  const [title, setTitle] = useState('');
  const [detail, setDetail] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    // 假设POST请求的URL为'/api/questions'
    await createQuestion({title: title, detail: detail, user_name: user.name,
    user_email: user.email});
    // 重定向到首页逻辑
    navigate('/');
  };

  return (
    <div className="container mt-4">
      <h1>提问</h1>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">问题内容</label>
          <input type="text" className="form-control" value={title} onChange={(e) => setTitle(e.target.value)} required />
        </div>
        <div className="mb-3">
          <label className="form-label">问题描述</label>
          <textarea className="form-control" value={detail} onChange={(e) => setDetail(e.target.value)} required />
        </div>
        <button type="submit" className="btn btn-primary">提交</button>
      </form>
    </div>
  );
};

export default AskQuestion;
