// src/components/Home.js
import React, { useState , useEffect } from 'react';
import { Link} from 'react-router-dom';
import { getQuestions} from '../api';

const Home = () => {
  const [Questions, setQuestions] = useState([
    {id: '', title: '', detail: '', author: '', author_email: '', created_at: '', answers: []}
  ]);

  useEffect(() => {
    const fetchQuestions = async () => {
      const response = await getQuestions();
      setQuestions(response);
    };
    fetchQuestions();
  }, []);
  return (
    <div className="container mt-4">
      <h1>问题列表</h1>
      <div className="list-group">
        {Questions.map((q) => (
          <div key={q.id}>
            <div className='list-group'>
              <div className='list-group-item'>
                <h5><label style={{marginRight: '20px',color:'grey'}}>标题: </label>{q.title}</h5>
                <p><label style={{marginRight: '20px',color:'grey'}}>详情: </label>{q.detail}</p>
              </div>
              <div className='list-group-item'>
              <div className='container'>
                <div className='row'>
                  <div className='col-4'>创建时间: {q.created_at}
                  </div>
                  <div className='col-4'>
                    <Link to={`/question/${q.id}`} className="btn-outline-primary">
                      <button type="button" class="btn btn-outline-primary btn-sm">查看详情</button>
                      
                    </Link>
                  </div>
                  <div className='col-4'><Link to={`/edit/${q.id}`} className="btn-outline-danger">
                  <button type="button" class="btn btn-outline-danger btn-sm">修改</button>
                  </Link>
                  </div>
                </div>
              </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Home;
