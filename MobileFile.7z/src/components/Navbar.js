// components/Navbar.js
import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav style={{
      width: '100%',
      padding: '10px',
      background: '#f0ffff', // 淡蓝色背景
      borderRadius: '8px', // 圆角
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      text_decoration: 'none',
    }}>
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <Link to="/" style={{ marginRight: 'auto', color: 'black', textDecoration: 'none' }}><h1>首页</h1></Link>
        <Link to="/ask" style={{ marginLeft: '20px', marginRight: '8px' , color: 'black', textDecoration: 'none' }}><h2>问</h2></Link>
      </div>
      <Link to="/user-profile" style={{ marginLeft: 'auto' , color: 'black', textDecoration: 'none'  }}><h2>用户</h2></Link>
    </nav>
  );
};

export default Navbar;
