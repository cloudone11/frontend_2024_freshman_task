// src/components/QuestionDetail.js
import React , { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
// import { questions } from '../data';
import { getAnswersByQuestionId , getQuestionById } from '../api';
const QuestionDetail = () => {
  const { id } = useParams();
  const [question, setQuestion] = useState({id: '', title: '', detail: '', author: '', author_email: '', created_at: '', answers: []});
  const [Answers, setAnswers] = useState([
    {id: '', content: '', author_name: '', author_email: '', created_at: '', is_best: false, question_id: ''}
  ]);
  useEffect(() => {
    getAnswersByQuestionId(id).then(res => {
      console.log(res);
      if (res){
        setAnswers(res);
      }else{
        console.log("no answers")
      }
      
    });
    getQuestionById(id).then(res => {
      console.log(res);
      setQuestion(res);
    });
  }, [id]);

  return (
    <div className="container mt-4">
      <div className="container mt-4">
        <ul className="list-group">
          <li className="list-group-item d-flex justify-content-center">
            <h1>{question.title}</h1>
          </li>
          <li className="list-group-item d-flex justify-content-center">
            <h3>{question.detail}</h3>
          </li>
          <li className="list-group-item d-flex justify-content-center">
            <h5>
                <button type="button" class="btn btn-outline-primary">
                  <Link to={`/question/${question.id}/addAnswer`}>
                    写回答
                  </Link>
                </button>
                创建时间: {question.created_at} 
            </h5>
          </li>
        </ul>

        <h2 className="text-center mt-4">回答如下</h2>
        {Answers.length > 1 ? (
            Answers.map(answer => (
              <div key={answer.id}>
                <ul className="list-group">
                  <li className="list-group-item">
                    <span className="text-primary">{answer.author_name}:</span> {answer.content}
                  </li>
                  <li className="list-group-item d-flex">
                    <button className="btn btn-primary me-2 disabled">点赞</button>
                    <button className="btn btn-primary me-2 disabled">反对</button>
                    <button className="btn btn-success me-2 disabled">评论</button>
                    <button className="btn btn-danger me-2">
                      <Link to={`/answer/${question.id}/edit/${answer.id}`} className="btn btn-sm-primary">修改回答</Link>
                    </button>
                    <button className="btn btn-success me-2 disabled">分享</button>
                  </li>
                </ul>
              </div>
            ))
          ) : (
            <p>暂无回答</p>
          )}
                
      </div>
    </div>
  );
};

export default QuestionDetail;
