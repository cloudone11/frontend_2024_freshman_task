// src/components/QuestionEdit.js
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import UserContext from '../context/UserContext';
import { getQuestionById , updateQuestion } from '../api';

const QuestionEdit = () => {
  const navigate = useNavigate();
  const { user } = React.useContext(UserContext);
  const { id } = useParams();
  const [title, setTitle] = useState('');
  const [detail, setDetail] = useState('');
  // const [question, setQuestion] = useState({id: '', title: '', detail: '', author: '', author_email: '', created_at: '', answers: []});
  
  useEffect(() => {
    // 模拟从后端获取数据
    const fetchQuestionDetails = async () => {
      const response = await getQuestionById(id);
      // setQuestion(response);
      setTitle(response.title);
      setDetail(response.detail);
    };

    fetchQuestionDetails();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const updatedQuestion = {
      id: Number(id),
      title: title,
      detail: detail,
      author: user.name,
      authorEmail: user.email,
      created_at: new Date().toISOString(),
    };

    try {
      // 在这里可以使用真实的API调用
      const response = await updateQuestion(id,updatedQuestion);
      console.log('Updated question:', response); // 打印更新信息用于调试
      navigate(`/question/${id}`); // 返回到问题详情页面
    } catch (error) {
      console.error('Error updating question:', error);
    }
  };

  return (
    <div className="container mt-4">
      <h1>编辑问1题</h1>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">问题标题</label>
          <input
            type="text"
            className="form-control"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">问题描述</label>
          <textarea
            className="form-control"
            value={detail}
            onChange={(e) => setDetail(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">提交</button>
      </form>
    </div>
  );
};

export default QuestionEdit;
