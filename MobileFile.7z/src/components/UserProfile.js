// src/components/UserProfile.js
import React from 'react';
import UserContext from '../context/UserContext';
const UserProfile = () => {
  const { user } = React.useContext(UserContext);
  return (
    <div className="container mt-4">
      <h1>用户中心</h1>
      <p>用户名: {user.name}</p>
      <p>邮箱: {user.email}</p>
    </div>
  );
};

export default UserProfile;
