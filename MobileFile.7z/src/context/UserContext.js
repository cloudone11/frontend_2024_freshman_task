import React from 'react';

const UserContext = React.createContext({
  user: {
    name: '',
    email: ''
  }
});

export default UserContext;