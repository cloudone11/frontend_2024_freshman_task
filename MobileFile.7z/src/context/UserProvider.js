import React, { useState } from 'react';
import UserContext from './UserContext';

const UserProvider = ({ children }) => {
  // 设置用户名和邮箱的初始值
  const [user, setUser] = useState({
    name: '初始用户名',
    email: '初始邮箱@example.com'
  });

  return (
    <UserContext.Provider value={{ user, setUser }}>
      {children}
    </UserContext.Provider>
  );
};

export default UserProvider;